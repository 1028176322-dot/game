---
name: encoding-pipeline-guard
description: Guard against UTF-8 encoding corruption in project source files. Use when creating, editing, or reviewing TypeScript/Python/JSON/MD files in a project with ENCODING_WRITE_POLICY and ASCII_SOURCE_POLICY rules. Also use when terminal display shows Chinese characters as garbled/mojibake.
agent_created: true
---

# Encoding Pipeline Guard

Guard against UTF-8 encoding corruption in project source files.

## When to Trigger

**CRITICAL — Must call this skill before any file write/edit operation in a project with encoding rules.** Do not assume Write/Edit tools produce UTF-8 correctly. Always load this skill first, then follow the workflow below.

- Any file creation or modification task (new file, edit, overwrite) in a project with encoding rules
- Terminal output of Chinese text appears garbled (`�` replacement characters or mojibake)
- After any source/config/doc change to validate encoding integrity
- When the project's `MEMORY.md` contains `ENCODING_WRITE_POLICY` or `ASCII_SOURCE_POLICY` rules

## Workflow

### Phase 1: Before Writing — Check the Write Tool's Encoding

The `Write` and `Edit` tools in WorkBuddy may or may not use UTF-8 by default. **Do not assume correctness.** Before writing any file with Chinese characters, verify:

1. Check if the file already exists — read it and confirm its current encoding:
   ```bash
   head -c 200 <file> | xxd | head -3
   ```
   Valid UTF-8 Chinese appears as multi-byte sequences (e.g. `e5 90 af` = 启).

2. On Windows, the default terminal codepage is GBK (cp936). Before running any command that reads/outputs file content with Chinese, switch to UTF-8:
   ```powershell
   chcp 65001
   ```

### Phase 2: Writing — Enforce UTF-8

When writing files with Chinese content (design docs, UI text, etc.):

1. **Always** include the encoding declaration in the file header:
   ```markdown
   > **编码**: UTF-8
   ```

2. **Never** use Python's `open(path, "w")` without explicit encoding — use `open(path, "w", encoding="utf-8")`.

3. **Never** use PowerShell's `Set-Content` without `-Encoding utf8`.

4. After writing with the `Write` or `Edit` tool, verify the file is valid UTF-8:
   ```bash
   cd <project_root>
   /c/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe -c "
   with open('<filepath>', 'rb') as f:
       raw = f.read(4096)
   try:
       raw.decode('utf-8')
       print('UTF-8_OK')
   except UnicodeDecodeError:
       print('NOT_UTF-8')
       import sys; sys.exit(1)
   "
   ```
   (Use the managed Python absolute path as shown above; `python3` resolves to a Windows Store stub on this system and may fail silently.)

### Phase 3: After Writing — Run Validation Gate

After any file creation or modification:

1. Run encoding audit:
   ```bash
   cd <project_root>
   python 回到地面/tools/encoding_audit.py --ci
   ```
   (If `python` is Python 3.13.12 managed, this works. On systems where `python3` points to a Windows Store stub, use `python` or the full managed path.)
   **Must pass**: `issues=0, p0=0, p1=0, p2=0`

2. Run full validation:
   ```bash
   cd <project_root>
   npm.cmd run validate:all
   ```

3. Only proceed to next task if both pass.

### Phase 4: Terminal Display Issue

If the user sees garbled Chinese in their terminal:

1. The file content is likely correct UTF-8 — the Windows terminal (cmd.exe / PowerShell) defaults to GBK (cp936) and displays UTF-8 Chinese as garbage.
2. Recommend the user to:
   - Use `chcp 65001` in PowerShell before `cat`/`type`
   - Or open the file in VS Code
   - Or use `git show` to view the file (Git handles encoding properly)
3. If the file itself is corrupted, run a recovery script.

## Encoding Audit Tool

The encoding audit tool is located at `回到地面/tools/encoding_audit.py` (relative to project root `E:/game/`).

To run:
```bash
cd E:/game/
python3 回到地面/tools/encoding_audit.py --ci
```

Key features:
- Scans: `assets/scripts/`, `assets/resources/config/`, `tools/`, `docs/`, `.workbuddy/memory/`
- Detects: U+FFFD replacement chars, comment truncation, unclosed block comments, garbled decoded text
- Exit code 0 = pass (issues=0, p0=0)

## Project Encoding Rules Summary

| Rule | Content | Scope |
|------|---------|-------|
| ENCODING_WRITE_POLICY | All writes must use explicit UTF-8. Run validation after any change. | All project files |
| ASCII_SOURCE_POLICY | Source code comments, tool scripts, engineering docs, memory files default to English/ASCII. Player-facing Chinese in `text.json` only. | Source code + docs |
