---
name: art-pipeline
description: Unified pipeline for generating, importing, and validating game art assets. Covers both procedural (Pillow) and AI (Agnes) generation, plus the full 12-step import workflow. **Must load ART_RESOURCE_RULES.md rules first before any operation.** Also provides `tools/art_pipeline.py` for single/category/full batch execution with progress tracking and resume. Supports a **2D image + 3D model dual-track**: 3D assets (characters/monsters/bosses/effects/tiles) skip AI generation and go through Blender→.glb→Prefab→`tools/asset_validate.py` validation (see §16).
agent_created: true
---

# Art Pipeline

## Overview

**Target platform: TapTap (Android).** Budget limits, resolution specs, and volume strategy are set for TapTap. WeChat Mini Game files are dev-phase artifacts.

This skill implements the project's art resource generation and import pipeline. All editorial constants (prompt anchors, style/safety text, transparency rules, palette steps, recommended sizes) are loaded from **`.workbuddy/memory/topics/ART_RESOURCE_RULES.md`** (Section 15 JSON config) at runtime. All AI prompts are in **`assets/resources/config/prompts.json`**. The Agnes API key comes from the **`AGNES_API_KEY`** environment variable. **`ART_RESOURCE_RULES.md` is the single authoritative rule source for ALL art resource data.**

The skill works at two levels:
- **Batch mode** (recommended for 3+ resources): run `python tools/art_pipeline.py` with the appropriate subcommand
- **Conversational mode** (for 1-2 resources or debugging): follow the 12-step workflow described below, and I will execute steps manually

All generated assets must pass through: **generate → master → visual_review(HUMAN) → technical_check → backup → import(HUMAN_APPROVAL_REQUIRED) → validate → finalize**.

> **🟦 2D / 3D 双轨 + 部件化动画**：本管线支持：
> - **3D 分支**：3D 化类别（monsters / bosses / effects / tiles）**不走 AI 出图**，资产由 Blender 制作 `.glb` → ASTC 贴图 → Cocos 导入生成 Prefab → `tools/asset_validate.py` 校验 → 登记入库（规则见 `ART_RESOURCE_RULES.md §16` + `docs/美术资源制作参数总表_3D.md`）。
> - **保留 2D 的类别**（icons / ui / backgrounds）走原有 AI 出图。
> - **部件化动画（2026-07-10 起）**：玩家角色（archer/warrior/mage/assassin/berserker）改为 2D 部件组装（PartCharacterRenderer + PartAnimationPlayer），部件单人单图（body/head/arm/leg 等），由 AI 生成单个部件图 → 后处理 → 母版入库 → Cocos 运行时组装。不再生成多帧 sprite sheet。见 `docs/角色.txt`。
> 
> 3D 维度判定来自 `assets/resources/config/prompts_dim.json`（由 key 前缀推导，非破坏性，不改动 `prompts.json`）。

> **⚠️ 人工确认是强制门禁**：生成后的资源和自检通过的资源，**必须由用户明确确认后才能导入 runtime**。不得在用户未确认的情况下自动或跳过人工审核执行导入。

## When to Invoke this Skill

Invoke this skill **immediately** when the user requests:
- Generate a new game asset (UI panel, button, background, character, monster, boss, tile, effect, icon)
- Replace an existing asset with a new version
- Crop, resize, or compress an existing asset
- Import a downloaded or AI-generated image into the project
- Fix or regenerate a problematic asset

The first action must be to load this skill, then read `ART_RESOURCE_RULES.md` and the relevant spec, then proceed. For **3D assets** (characters/monsters/bosses/effects/tiles) also read `docs/美术资源制作参数总表_3D.md` and `ART_RESOURCE_RULES.md §16` (see Mandatory First Step below).

## Mandatory First Step: Read Rules & Spec

**Before any generation, replacement, import, or registration of art assets, you MUST first load and follow `.workbuddy/memory/topics/ART_RESOURCE_RULES.md`.** This file contains:

| Section | Content |
|---|---|
| Style & prompts | Current style direction, forbidden styles, positive description rules (Section 1) |
| Pipeline rules | Art-pipeline / encoding-pipeline-guard invocation, 12-step pipeline (Section 2) |
| Format & specs | File format, runtime size, bundle mapping, 9-slice standards (Section 3) |
| Registration | Asset registration, runtime assembly rules (Section 4) |
| Naming | File and directory naming conventions (Section 6) |
| Safety | WeChat review requirements, prompt safety rules (Section 7) |
| Encoding | UTF-8 enforcement, validation gates (Section 8) |
| Volume | Budget strategy and reference sizes (Section 9) |
| Directory | Formal resource dir vs working dir rules (Section 10) |
| **3D rules** | **3D 资源唯一权威（命名/预算/目录/生命周期/依赖）：`CHR_`/`MON_`/`BOSS_`/`FX_`/`TILE_` + PascalCase，禁止各自硬编码 (Section 16)** |
| SOP | Standard operating procedure for new resources (Section 11) |

Then also read the full project spec:

```text
docs/美术资源生成与入库规范.md
```

If the asset is specifically a UI panel/button/input field, also read the 9-Slice section of the spec.

For **3D assets** (characters / monsters / bosses / effects / tiles), also read the following **before** any generation/import step:

```text
docs/美术资源制作参数总表_3D.md        # 逐资源 3D 制作参数（总表 v5）：命名/预算/LOD/依赖/生命周期
../docs/2D转3D全面升级方案.md            # 升级方案 v3，第 3/4/5 章：3D 渲染/动画/装配/资源管线
.workbuddy/memory/topics/ART_RESOURCE_RULES.md  §16   # 3D 唯一权威规则源（命名/预算/目录/生命周期）
```

## Batch Mode (Preferred for Multiple Resources)

For generating or re-importing 3+ resources, use the batch script instead of conversational flow:

```bash
# Audit first: check what needs to be done
python tools/art_pipeline.py audit
python tools/art_pipeline.py audit --category backgrounds

# Generate (single / category / all)
python tools/art_pipeline.py generate --resource backgrounds/bg_combat_forest.jpg
python tools/art_pipeline.py generate --category ui/create --limit 5
python tools/art_pipeline.py generate --all --limit 10
python tools/art_pipeline.py generate --resume-failed    # retry only failed items
python tools/art_pipeline.py generate --category bosses --force  # force regenerate

# Technical validation
python tools/art_pipeline.py validate --all

# Generate contact sheet for visual review
python tools/art_pipeline.py contact --category ui/create

# Import approved resources to textures/
# ❗ 必须先获得用户明确确认（"可以"或"入库"），否则不执行 import
python tools/art_pipeline.py import --all

# Regenerate progress report (after import)
python ../.workbuddy/tmp_resource_status.py

# Progress management
python tools/art_pipeline.py status
python tools/art_pipeline.py status --category backgrounds
python tools/art_pipeline.py reset --category bosses
```

#### Prompt Rules Maintenance — Sync All Prompts from Authoritative Rules

When `ART_RESOURCE_RULES.md` §15 config (recommended_sizes, ui_kit_default_dims, palettes, safety words) or `docs/资源提示词设计策略.md` (9-block template, classification strategy, compliance constraints) are updated, **regenerate all prompts** to reflect the new rules:

```bash
# 1. Regenerate ALL prompts from rules (backup old prompts.json automatically)
python ../tools/normalize_prompts_positive_style.py

# 2. Run risk filter on the new prompts.json — inspect risk_count in output
#    (risk hits from common words like "no" are acceptable; hits from
#     blood/skull/bone/heart/coffin require immediate correction)

# 3. Validate UTF-8 integrity
cd ../回到地面
python tools/encoding_audit.py --ci
```

> ⚠️ This step is NOT part of daily generation — run it only when prompt rules change (e.g. new canvas sizes, updated zone palettes, added compliance words). The script reads `ART_RESOURCE_RULES.md` §15 JSON + `docs/资源提示词设计策略.md` templates at runtime and rewrites all 499+ prompts in `prompts.json` accordingly.

#### 3D Asset Commands (characters / monsters / bosses / effects / tiles)

3D assets are **NOT generated by AI**. They are produced externally (Blender → `.glb` → ASTC → Prefab) and only **validated / registered / imported** by this pipeline.

```bash
# Validate a single 3D asset's manifest against rules3d budget
python tools/asset_validate.py assets/resources/models/characters/CHR_Archer_A.assetmeta.json

# Scan a whole 3D directory (models/) and emit a CSV report
python tools/asset_validate.py --scan assets/resources/models/ --report art_source/models_review/validate_report.csv

# Self-test the validator (must PASS before trusting its output)
python tools/asset_validate.py --self-test
```

**3D import flow** — `art_pipeline.py import --mode 3d` routes 3D assets (driven by `art_3d_manifest.json`) to `assets/resources/models/` + `assets/resources/prefabs/`, **never** to `textures/`. Default mode is `2d` (2D-compatible, never blocks current 2D sprite production):

```bash
# 生成/校验 3D 资产注册表（从 L1 文档单一来源解析，134 项）
python tools/gen_3d_manifest.py          # 生成 art_3d_manifest.json
python tools/gen_3d_manifest.py --check   # 仅校验数量是否匹配 L1 总表

# 3D 校验 / 入库：--mode 3d 走 manifest，强制 asset_validate 通过（未过禁止入库）
python tools/art_pipeline.py validate --mode 3d --category monsters   # 复用 asset_validate.py 单一来源
python tools/art_pipeline.py import  --mode 3d --category bosses      # .glb→models/；.prefab→prefabs/
python tools/art_pipeline.py import  --mode 3d --resource CHR_Archer_A
```

> **3D 资产不经过 Agnes 生成**：`--mode 3d` 下 `cmd_generate` 对 3D 维度资产会打印「跳过 AI 生成（3D 资产，需经 Blender→glb→Prefab 流程）」并跳过出图；`--mode 2d`（默认）则正常生成 2D sprite，不被 3D 升级阻断。

The script supports **interrupt and resume**: progress is saved after each resource via `art_source/textures_review/art_pipeline_progress.json`. Use `--resume-failed` to retry only failed items.

Add `--self-check` to auto-run **technical validation** after generation:
```bash
python tools/art_pipeline.py generate --category ui/create --limit 5 --self-check
```
The self-check verifies: **dimensions match expected → mode is RGBA/RGB (not indexed) → alpha has smooth transitions → opaque pixel ratio meets minimum → no chroma residuals → file volume within budget**.

After the self-check, generated resources are marked as `validated` (ready for import) only if all checks pass. Failed checks block the resource from being imported and mark it as `failed` for retry.

All category rules (budget, palette, transparency, detail anchors, recommended sizes) are loaded from `ART_RESOURCE_RULES.md` at runtime. **Budget limits are read from Section 9.2 — all other pipeline constants from Section 15 JSON config.** The API key is read from the **`AGNES_API_KEY`** environment variable.

## Manual Mode: 12-Step Workflow

### Step 1 — Confirm Asset Specs

First look up the resource in `assets/resources/config/prompts.json`:

| Spec | Source |
|---|---|
| **Path** | Key in prompts.json (flat JSON: `"filename": "prompt text"`) |
| **Size** | Extract `WIDTHxHEIGHT` from prompt text via regex (if present) |
| **Format** | From filename extension: `.png` → RGBA, `.jpg` → RGB |
| **Category** | First segment of the key (`ui/`, `backgrounds/`, `bosses/`, etc.) |
| **Volume budget** | `ART_RESOURCE_RULES.md` Section 9.2 — parsed by `tools/art_pipeline.py` at runtime |
| **Slice config** | `ui_assets.json` for UI resources |
| **Category rules** | Built into `tools/art_pipeline.py` (loaded from `ART_RESOURCE_RULES.md` via code) |

For resources NOT in prompts.json (new or procedural UI), ask the user for path, size, and format.

### Step 2 — Determine Generation Method

| Type | Method | Details |
|---|---|---|
| UI panels, buttons, input fields | AI (Agnes) | `prompts.json` 的 `ui/...` 条目 + `tools/art_pipeline.py generate --category ui` |
| Tiles (2D floor/wall variants) | Procedural | Pillow-generated 2D tile textures via `tools/art_pipeline.py generate` |
| Backgrounds, icons | AI (Agnes) | Use Agnes API via the batch script or manual curl call |
| **Tiles (3D module pieces)** | **3D — Blender** | 24 module pieces (Floor/Wall/HighGround/Thorn/Corner/Edge/Slope/Ramp) per §16.1. Build in Blender → `.glb` → `asset_validate`. **Not** AI, **not** Pillow. |
| **Characters (player parts)** | **2D AI (Agnes)** | 部件化动画（2026-07-10 起）：玩家角色改为部件组装，AI 生成单人单图（body/head/arm/leg/tail/bow/quiver/cape），后处理抠背景去水印缩放到规格尺寸。路径 `art_source/textures_review/master/characters/{profession}/parts/`。配置见 `character_parts.json`/`character_rigs.json`/`character_part_animations.json`，Cocos 端用 `PartCharacterRenderer`+`PartAnimationPlayer`。详见 `docs/角色.txt`。 |
| **Monsters, bosses, effects** | **3D — Blender→glb→Prefab** | 3D assets per `ART_RESOURCE_RULES.md §16.1`. Generate in Blender, export `.glb`, import into Cocos to produce `.prefab`, then run `tools/asset_validate.py`. **Do NOT call Agnes for these.** |

For AI generation:
- Check prompts.json for existing entry → reuse if master still valid
- If new, construct prompt using `detail_anchors[category]` from `tools/art_pipeline.py` (constants built from `ART_RESOURCE_RULES.md`)
- Build prompt as: `{style_anchor} {original_prompt} {detail_anchor} {safety_block}`
- Run risk filter: do NOT send dangerous words (blood, skull, bone, heart, corpse, horror) as positive words
- For "death" actions, rephrase to: `adventure failed settlement`, `fade into light`

### Step 3-12 (Same as Before)

| Step | Action |
|---|---|
| 3 | Save master to `art_source/textures_review/master/{category}/{filename}` |
| 4 | **Visual review (人工确认)**: 展示生成的图片给用户 → **必须用户口头确认"可以"或"入库"** |
| | **↓ 人工确认门禁 ↓** — 未获用户确认不得进入 Step 5 |
| 5 | Export runtime candidate to `runtime_candidates/`; for AI: post-process (matte removal, chroma cleanup, palette reduction) |
| 6 | Technical check: path, naming, size, format, alpha, volume |
| 7 | Backup old file to `art_source/textures_review/backup/{timestamp}/` |
| 8 | **Import (仅限已确认)**: 用户确认 ✅ 后复制到 `assets/resources/textures/{category}/{filename}` |
| 9 | Update `assets.json`, `ui_assets.json`, or `game_assets.json` if new |
| 10 | Run `npm.cmd run validate:all` |
| 11 | Cocos Preview — confirm no console errors |
| 12 | Mark approved in progress file |

#### 3D Technical Check (replaces Step 6 for 3D assets)

For 3D assets, `art_pipeline.py validate` delegates to **`tools/asset_validate.py`**. The manual equivalent of Step 6 is:

```bash
python tools/asset_validate.py assets/resources/models/<cat>/<NAME>.assetmeta.json
```

It checks (order: naming → budget → structure → meta):
- **naming** — `CHR_`/`MON_`/`BOSS_`/`FX_`/`TILE_` + PascalCase, regex from `rules3d.naming` (§16.2)
- **budget** — Tri / bones / textureSize / LOD levels / animClip count, per `art_quality_budget.json → rules3d` (§16.3)
- **sockets / colliders** — required socket set and at least one collider present (§16.2 / §16.5)
- **depends[]** — every referenced token (weapon / FX / audio / sub-model) must exist
- **lifecycle** — must be `已批准` to be allowed into runtime (§16.6)
- **meta fields** — `version` / `author` / `date` / `reviewer` present (§16.5)

> **🚫 3D 资产未通过 `asset_validate` 一律禁止入库。** Any FAIL item must be fixed (or the asset explicitly downgraded via `lifecycle`) before Step 8 (Import).

### Step 13 — Update Resource Progress Report

After import + validate is complete for a category or batch, regenerate the authoritative progress report:

> **`docs/progress/resource_status.md`** 是项目的 **资源进度追踪唯一权威来源**（参见 `ART_RESOURCE_RULES.md` §14.4）。
> 每次完成一批资源的生成/入库/审核后，必须重新生成此文件以确保进度状态一致。

**手动生成**（使用已固化的脚本）：
```bash
# 从项目根目录运行（以下路径均相对项目根）：
python .workbuddy/tmp_resource_status.py
```

> ⚠️ `generate_resource_status.py`（计划中的工具）尚未创建——当前资源状态查看请使用 `python tools/art_pipeline.py status`。

**验证**：生成后检查总览表数值是否与实际情况一致（母版数、生成数、入库数）。

## UI Generation (AI / Agnes)

> **2D→3D 升级（2026-07-10）：`ui/` 目录下全部资源改为 AI 出图**（按钮/面板/卡片/槽位/输入框/徽章/头像框等）。`prompts.json` 已有 173 条 `ui/...` AI 提示词，统一由 `tools/art_pipeline.py generate --category ui` 生成，不调用任何程序化生成器。

生成方式判定见 `tools/art_pipeline.py` 的 `classify_resource()`：`is_procedural` 仅当 `category in PROCEDURAL_CATEGORIES`（当前为空集）时为真，UI 一律走 AI（Agnes）。

UI 提示词模板与差异变量见 `docs/资源提示词设计策略.md` §5.3。关键约束：9-slice 边框须**四角完全透明、中心留空**给 Label；体积与 9-slice 边距见 `ART_RESOURCE_RULES.md` §3 / §9.2。

### 回滚兜底（不推荐）
历史程序化生成器 `tools/ui_kit_generator.py` 仍保留，但当前不被任何 UI 资源调用。若需恢复程序化，恢复 `art_pipeline.py` 中 `KIND_PROCEDURAL_UI` 正则并接入 `classify_resource` / `is_procedural`。

## Configuration Files Reference

| File | Purpose | Path |
|---|---|---|
| Art resource rules | Authoritative rule source: style, format, registration, safety, pipeline | `.workbuddy/memory/topics/ART_RESOURCE_RULES.md` |
| Prompts | All AI prompts, flat `{filename: prompt}` | `assets/resources/config/prompts.json` |
| Progress tracking (pipeline) | Resume state from batch script | `art_source/textures_review/art_pipeline_progress.json` |
| **Resource progress report** | **唯一权威资源进度总表（§14.4）** | **`docs/progress/resource_status.md`** |
| Budget limits | Read from ART_RESOURCE_RULES.md (Section 9.2) — authoritative source | (parsed from rules file at runtime) |
| Project spec | Master spec document | `docs/美术资源生成与入库规范.md` |
| **3D production spec** | **逐资源 3D 制作参数（总表 v5）：命名/预算/LOD/依赖/生命周期** | **`docs/美术资源制作参数总表_3D.md`** |
| **3D validator** | **3D 技术校验器入口（Tri/Bone/Socket/Collider/LOD/依赖/命名）** | **`tools/asset_validate.py`** |
| **3D budget** | **`rules3d` 段：Tri/骨/贴图/LOD/粒子预算（唯一权威数值源）** | **`assets/resources/config/art_quality_budget.json` (key `rules3d`)** |
| **3D dimension registry** | **每资源 2d/3d 维度标注（非破坏性，由 key 前缀推导）** | **`assets/resources/config/prompts_dim.json`** |
| **3D asset manifest** | **134 项 3D 资产注册表（CHR_/MON_/BOSS_/FX_/TILE_ 真实名 + bucket + 源 2D），3D 批次唯一驱动源** | **`assets/resources/config/art_3d_manifest.json`（由 `tools/gen_3d_manifest.py` 从 L1 文档生成）** |
| **Prompt rules sync** | **从权威规则重写全部 prompts（画布/调色板/安全词更新后运行）** | **<code>../tools/normalize_prompts_positive_style.py</code>（项目根 `tools/`，非 `回到地面/tools/`）** |
| **Prompt design strategy** | **提示词设计策略文档：9 块模板、分类策略、技术约束、合规要求** | **`docs/资源提示词设计策略.md`** |

## Maintenance: Sync Prompts from Rules

When `ART_RESOURCE_RULES.md` §15 JSON config, `docs/资源提示词设计策略.md` templates, or `normalize_prompts_positive_style.py` itself are modified, all 499+ AI prompts in `prompts.json` must be **regenerated** to stay aligned with the rules.

### When to Run
- After changing canvas sizes (recommended_sizes / ui_kit_default_dims)
- After adding/removing module palettes
- After updating safety/compliance words
- After modifying the 9-block template structure
- After adding new assets to textures/ (new file needs a prompt)

### How to Run
```bash
# From project root E:/game/ (one level up from 回到地面/)
python ../tools/normalize_prompts_positive_style.py

# Output: prompts.json (499+ entries, backup auto-saved)
#          tools/output/prompts_positive_style_report_*.json (risk hits + category counts)
```

### What It Does
1. Reads `ART_RESOURCE_RULES.md` §15 JSON (sizes, dimensions, palettes) at runtime
2. Scans `assets/resources/textures/` for all existing files
3. For each file, generates a complete 9-block AI prompt using templates from `docs/资源提示词设计策略.md`
4. Applies category-specific logic: zone palettes for backgrounds, module palettes for UI, ICON_SAFE_MAP for icons, MONSTER_DESIGN_MAP/EFFECT_MAP for creatures, terrain_feature table for tiles
5. Runs risk filter (skull/bone/blood/heart) on each prompt
6. Writes `prompts.json` with auto-backup of the old file

### Verification
```bash
# 1. Check risk_count in CLI output — 0 unknown risks expected
#    (known false positive: "no" in "no badge label, no text" is safe)

# 2. Validate UTF-8
cd 回到地面 && python tools/encoding_audit.py --ci

# 3. Sample-check critical prompts: background jpg → 1920x1080, btn → 240x80
python -c "
import json, re
with open('../assets/resources/config/prompts.json') as f:
    p = json.load(f)
for k in ['backgrounds/bg_combat_forest.jpg','ui/common/btn_default.png','icons/icon_coin.png']:
    m = re.search(r'Target canvas: (\d+x\d+)', p.get(k,''))
    print(f'{k:45s} -> {m.group(1) if m else \"NONE\"} ')
"
```

> 🔗 本维护步骤的 prompt 模板定义来源：`docs/资源提示词设计策略.md`（§5 分类型策略 + §6 差异治理）。实际提示词数据产物：`assets/resources/config/prompts.json`。两者共同由 `normalize_prompts_positive_style.py` 保证一致性。

## Violation Warnings

| Violation | Why |
|---|---|
| Writing backup `.bak` to `assets/resources/textures/` | Pollutes project directory, confuses Cocos import |
| Copying files to textures/ without master/candidate staging | Bypasses quality control and registration |
| Skipping `ART_RESOURCE_RULES.md` before any operation | Missing style/safety/format constraints may produce non-compliant assets |
| Using AI without reading/updating prompts.json | Loss of prompt history, duplicate API calls |
| Committing textures without running `validate:all` | Missing config registration or format issues |
| Placing AI prompt risk words (blood/skull/bone) as positive prompt | Risk filter violation, may trigger review rejection |
| Not backing up before replacing | Irreversible data loss risk |
| **Importing assets without explicit user confirmation** | **Violates mandatory human approval gate — user must say "可以" or "入库" before import** |
| Importing assets without regenerating `docs/progress/resource_status.md` | Progress tracking becomes stale; violates §14.4 single-source principle |
| **将 `.glb`/`.prefab` 直接丢进 `assets/resources/textures/`** | 3D 模型/Prefab 必须进 `models/`+`prefabs/`，混入 `textures/` 会污染 2D 贴图目录并破坏单源（§16.4） |
| **3D 资产未过 `asset_validate.py` 即入库** | 越预算/缺 Socket/缺 Collider/缺依赖的资产进入 runtime，违反 Step 6 3D 门禁 |
| **3D 资产未登记 `depends[]` 即 import** | 依赖缺失（武器/FX/音频/子模型）导致运行时装配失败 |
| **3D 命名不符 `CHR_/MON_/BOSS_/FX_/TILE_` 前缀** | 违反 §16.2 双轨命名，会被 `asset_validate` 判 FAIL |
| **3D 资产 `lifecycle` ≠ `已批准` 即接入** | 仅「已批准」可正式接入，选秀/评审中/已弃用不得进 runtime（§16.6） |
