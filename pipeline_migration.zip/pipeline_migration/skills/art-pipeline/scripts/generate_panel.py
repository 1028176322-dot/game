# -*- coding: utf-8 -*-
"""Generate a clean, procedural UI panel texture (RGBA PNG) using Pillow.

No AI generation is used, so the output is free of watermarks, text artifacts,
and irregular shadows. Typical uses: naming panels, input fields, dialog boxes,
frames, or other wood/parchment-style UI elements that need 9-slice scaling.
"""
import os
import math
import random
import argparse
from PIL import Image, ImageDraw

# Default warm-forest parchment palette
DEFAULT_BG_TOP = (252, 246, 232)
DEFAULT_BG_MID = (245, 235, 210)
DEFAULT_BG_BOTTOM = (238, 224, 192)
DEFAULT_BORDER_OUTER = (185, 152, 108)
DEFAULT_BORDER_INNER = (232, 214, 174)
DEFAULT_LEAF_GREEN = (126, 179, 66)
DEFAULT_LEAF_DARK = (96, 139, 46)


def make_rounded_mask(size, radius, antialias=4):
    """Create a rounded rectangle alpha mask with anti-aliased edges."""
    w, h = size
    # Draw at higher resolution then downsample for anti-aliasing
    aw, ah = w * antialias, h * antialias
    ar = radius * antialias
    big = Image.new('L', (aw, ah), 0)
    d = ImageDraw.Draw(big)
    d.rounded_rectangle([0, 0, aw - 1, ah - 1], radius=ar, fill=255)
    mask = big.resize((w, h), Image.LANCZOS)
    return mask


def wood_grain_layer(size, alpha=14):
    img = Image.new('RGBA', size, (0, 0, 0, 0))
    pixels = img.load()
    for x in range(size[0]):
        base = math.sin(x / 18.0) * 0.5 + math.sin(x / 7.0) * 0.25
        for y in range(size[1]):
            noise = random.uniform(-0.35, 0.35)
            val = int((base + noise) * alpha)
            pixels[x, y] = (120, 90, 60, max(0, min(255, val)))
    return img


def draw_leaf(draw, cx, cy, angle, scale=1.0, green=DEFAULT_LEAF_GREEN, dark=DEFAULT_LEAF_DARK):
    pts = []
    for t in range(0, 360, 10):
        rad = math.radians(t)
        r = 1.0 + 0.12 * math.cos(2 * rad)
        x = r * math.cos(rad) * 12 * scale
        y = r * math.sin(rad) * 7 * scale
        xr = x * math.cos(angle) - y * math.sin(angle)
        yr = x * math.sin(angle) + y * math.cos(angle)
        pts.append((cx + xr, cy + yr))
    draw.polygon(pts, fill=green, outline=dark)
    vx = cx + math.cos(angle) * 8 * scale
    vy = cy + math.sin(angle) * 8 * scale
    draw.line([(cx, cy), (vx, vy)], fill=dark, width=1)


def generate_panel(width=360, height=200, radius=22, output="panel.png",
                   bg_top=DEFAULT_BG_TOP, bg_mid=DEFAULT_BG_MID, bg_bottom=DEFAULT_BG_BOTTOM,
                   border_outer=DEFAULT_BORDER_OUTER, border_inner=DEFAULT_BORDER_INNER,
                   leaf_green=DEFAULT_LEAF_GREEN, leaf_dark=DEFAULT_LEAF_DARK,
                   leaves=True, grain_alpha=14, seed=None):
    if seed is not None:
        random.seed(seed)

    base = Image.new('RGBA', (width, height), bg_mid)
    pixels = base.load()
    for y in range(height):
        for x in range(width):
            t = (x / width + y / height) / 2.0
            t = max(0.0, min(1.0, t))
            r = int(bg_top[0] * (1 - t) + bg_bottom[0] * t)
            g = int(bg_top[1] * (1 - t) + bg_bottom[1] * t)
            b = int(bg_top[2] * (1 - t) + bg_bottom[2] * t)
            pixels[x, y] = (r, g, b, 255)

    grain = wood_grain_layer((width, height), alpha=grain_alpha)
    base = Image.alpha_composite(base, grain)

    border_layer = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(border_layer)
    d.rounded_rectangle([0, 0, width - 1, height - 1], radius=radius, outline=border_outer, width=4)
    d.rounded_rectangle([3, 3, width - 4, height - 4], radius=max(0, radius - 3), outline=border_inner, width=2)
    hl = (255, 255, 255, 35)
    sh = (100, 75, 45, 40)
    d.arc([5, 5, width - 6, height - 6], start=180, end=270, fill=hl, width=2)
    d.arc([5, 5, width - 6, height - 6], start=0, end=90, fill=sh, width=2)

    base = Image.alpha_composite(base, border_layer)

    mask = make_rounded_mask((width, height), radius)
    base.putalpha(mask)

    if leaves:
        leaf_layer = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        d = ImageDraw.Draw(leaf_layer)
        margin_x = min(28, width // 6)
        margin_y = min(28, height // 4)
        draw_leaf(d, margin_x, margin_y, math.radians(-45), 1.0, leaf_green, leaf_dark)
        draw_leaf(d, width - margin_x, margin_y, math.radians(-135), 1.0, leaf_green, leaf_dark)
        draw_leaf(d, margin_x, height - margin_y, math.radians(45), 1.0, leaf_green, leaf_dark)
        draw_leaf(d, width - margin_x, height - margin_y, math.radians(135), 1.0, leaf_green, leaf_dark)
        base = Image.alpha_composite(base, leaf_layer)

    os.makedirs(os.path.dirname(os.path.abspath(output)) or '.', exist_ok=True)
    base.save(output, 'PNG')
    return output


def main():
    parser = argparse.ArgumentParser(description="Generate a clean procedural UI panel texture.")
    parser.add_argument("--width", type=int, default=360)
    parser.add_argument("--height", type=int, default=200)
    parser.add_argument("--radius", type=int, default=22)
    parser.add_argument("--output", type=str, default="panel.png")
    parser.add_argument("--no-leaves", action="store_true", help="Omit corner leaf decorations")
    parser.add_argument("--seed", type=int, default=20260708)
    args = parser.parse_args()

    generate_panel(width=args.width, height=args.height, radius=args.radius, output=args.output,
                   leaves=not args.no_leaves, seed=args.seed)
    print(f"Saved panel to: {args.output}")


if __name__ == '__main__':
    main()
